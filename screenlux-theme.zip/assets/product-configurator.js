class ProductConfigurator extends HTMLElement {
  constructor() {
    super();
    this.form = this.querySelector('form');
    this.screensContainer = this.querySelector('#screens-container');
    this.addScreenBtn = this.querySelector('#add-screen-btn');
    this.solarTip = this.querySelector('#solar-tip');
    this.switchToSolarBtn = this.querySelector('#switch-to-solar-btn');
    this.installationRadios = this.querySelectorAll('input[name="installation-type"]');
    this.summaryContent = this.querySelector('#order-summary-content');

    this.state = {
      screens: [],
      installationType: 'diy'
    };

    // Initialize with one screen
    this.addScreen();

    this.bindEvents();
    this.render();
  }

  bindEvents() {
    this.addScreenBtn.addEventListener('click', () => this.handleAddScreen());
    this.switchToSolarBtn.addEventListener('click', () => this.updateAllScreens({ solar: true }));
    
    this.installationRadios.forEach(radio => {
      radio.addEventListener('change', (e) => {
        this.state.installationType = e.target.value;
        this.renderInstallationVisibility();
      });
    });

    // Event delegation for screen updates (input changes inside screens)
    this.screensContainer.addEventListener('change', (e) => {
      const screenEl = e.target.closest('.screen-item');
      if (screenEl) {
        const index = parseInt(screenEl.dataset.index);
        this.updateScreenData(index, e.target);
      }
    });

    // Delete screen delegation
    this.screensContainer.addEventListener('click', (e) => {
       if (e.target.closest('.delete-screen')) {
         const index = parseInt(e.target.closest('.screen-item').dataset.index);
         this.removeScreen(index);
       }
    });
  }

  handleAddScreen() {
    const currentScreen = this.state.screens[this.state.screens.length - 1];
    if (this.validateScreen(currentScreen)) {
      // Collapse current
      this.collapseAllScreens();
      // Add new
      this.addScreen();
    } else {
      alert('Please complete the current screen configuration first.');
    }
  }

  addScreen() {
    this.state.screens.push({
      id: Date.now(),
      width: 1500,
      height: 1000,
      solar: false,
      isOpen: true
    });
    this.renderScreens();
  }

  removeScreen(index) {
    if (this.state.screens.length > 1) {
      this.state.screens.splice(index, 1);
      this.renderScreens();
    }
  }

  updateScreenData(index, target) {
    const screen = this.state.screens[index];
    if (target.name.includes('width')) screen.width = target.value;
    if (target.name.includes('height')) screen.height = target.value;
    if (target.name.includes('solar')) screen.solar = target.checked;
    
    this.render(); // Re-render derived state (summary, solar tip)
  }

  updateAllScreens(updates) {
    this.state.screens.forEach(screen => {
      Object.assign(screen, updates);
    });
    this.renderScreens(); // Re-render inputs
    this.render(); // Re-render global state
  }

  collapseAllScreens() {
    this.state.screens.forEach(s => s.isOpen = false);
    // Note: In a real DOM diffing setup this would update state. 
    // Here we might just start the next valid render with isOpen=false for others.
  }

  validateScreen(screen) {
    // Basic validation
    return screen.width && screen.height; 
  }

  render() {
    this.checkGlobalSolar();
    this.renderInstallationVisibility();
    this.renderSummary();
  }

  renderScreens() {
    this.screensContainer.innerHTML = this.state.screens.map((screen, index) => `
      <div class="screen-item" data-index="${index}">
        <details-accordion>
          <details ${screen.isOpen ? 'open' : ''}>
            <summary>
              <span>Screen ${index + 1} (${screen.width}mm x ${screen.height}mm)</span>
              ${index > 0 ? '<button type="button" class="delete-screen">Remove</button>' : ''}
              <span class="icon-caret">▼</span>
            </summary>
            <div class="accordion__content">
              <label>Width (mm) <input type="number" name="width" value="${screen.width}"></label>
              <label>Height (mm) <input type="number" name="height" value="${screen.height}"></label>
              <label><input type="checkbox" name="solar" ${screen.solar ? 'checked' : ''}> Solar Powered</label>
            </div>
          </details>
        </details-accordion>
        <!-- Hidden inputs for form submission -->
        <input type="hidden" name="properties[Screen ${index + 1} - Dimensions]" value="${screen.width}x${screen.height}">
        <input type="hidden" name="properties[Screen ${index + 1} - Power]" value="${screen.solar ? 'Solar' : 'Standard'}">
      </div>
    `).join('');
    
    // Check global state after rendering
    this.render();
  }

  checkGlobalSolar() {
    const allSolar = this.state.screens.every(s => s.solar);
    if (allSolar) {
      this.solarTip.classList.add('hidden');
    } else {
      this.solarTip.classList.remove('hidden');
    }
  }

  renderInstallationVisibility() {
    const bracketSection = this.querySelector('#bracket-options');
    if (this.state.installationType === 'diy') {
      bracketSection.classList.remove('hidden');
    } else {
      bracketSection.classList.add('hidden');
    }
  }

  renderSummary() {
    // Aggregation Logic
    const groups = {};
    this.state.screens.forEach(s => {
      const key = `${s.width}x${s.height}-${s.solar ? 'Solar' : 'Standard'}`;
      if (!groups[key]) groups[key] = { count: 0, items: [] };
      groups[key].count++;
      groups[key].items.push(s);
    });

    let html = '';
    for (const [key, group] of Object.entries(groups)) {
       html += `
         <div class="summary-item">
           <strong>Zip-screen (${group.count})</strong>
           <div class="summary-details">
             ${group.items[0].width}mm x ${group.items[0].height}mm
             <br>Power: ${group.items[0].solar ? 'Solar' : 'Standard'}
           </div>
         </div>
       `;
    }
    this.summaryContent.innerHTML = html;
  }
}

customElements.define('product-configurator', ProductConfigurator);
