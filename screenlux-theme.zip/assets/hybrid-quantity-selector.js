class HybridQuantitySelector extends HTMLElement {
  constructor() {
    super();
    this.addButton = this.querySelector('.add-browser-btn');
    this.quantityWrapper = this.querySelector('.quantity-wrapper');
    this.valueDisplay = this.querySelector('.quantity-display');
    this.input = this.querySelector('input[type="hidden"]');
    
    this.min = parseInt(this.getAttribute('min')) || 0;
    this.value = parseInt(this.getAttribute('value')) || 0;

    this.render();

    this.addEventListener('click', (e) => {
      if (e.target.matches('.add-browser-btn')) {
        this.updateValue(1);
      } else if (e.target.matches('[name="minus"]')) {
        this.updateValue(this.value - 1);
      } else if (e.target.matches('[name="plus"]')) {
        this.updateValue(this.value + 1);
      }
    });
  }

  updateValue(newValue) {
    this.value = newValue;
    if (this.input) this.input.value = this.value;
    this.dispatchEvent(new CustomEvent('change', { detail: { value: this.value } }));
    this.render();
  }

  render() {
    if (this.value > 0) {
      this.addButton.classList.add('hidden');
      this.quantityWrapper.classList.remove('hidden');
      if (this.valueDisplay) this.valueDisplay.textContent = this.value;
    } else {
      this.addButton.classList.remove('hidden');
      this.quantityWrapper.classList.add('hidden');
    }
  }
}

customElements.define('hybrid-quantity-selector', HybridQuantitySelector);
